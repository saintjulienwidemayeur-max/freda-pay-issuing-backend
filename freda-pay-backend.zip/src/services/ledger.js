'use strict';
const supabase = require('../lib/supabase');

/**
 * Record a ledger movement. `amount` should be signed: positive = credit,
 * negative = debit. This is the single source of truth for balances -
 * we never store a running balance column, we always derive it by summing
 * (see get_balance() Postgres function in supabase-schema.sql).
 */
async function record({ merchantId, wallet, type, amount, currency, reference, relatedId }) {
  return supabase.insert('ledger_entries', {
    merchant_id: merchantId,
    wallet,
    type,
    amount,
    currency: currency || 'HTG',
    reference: reference || null,
    related_id: relatedId || null,
  });
}

async function getBalance(merchantId, wallet, currency) {
  const balance = await supabase.rpc('get_balance', {
    p_merchant_id: merchantId,
    p_wallet: wallet,
    p_currency: currency || 'HTG',
  });
  return Number(balance) || 0;
}

async function creditGateway(merchantId, amount, currency, reference, relatedId) {
  return record({ merchantId, wallet: 'gateway', type: 'payment_credit', amount, currency, reference, relatedId });
}

async function debitGatewayForPayout(merchantId, amount, currency, reference, relatedId) {
  return record({
    merchantId,
    wallet: 'gateway',
    type: 'payout_debit',
    amount: -Math.abs(amount),
    currency,
    reference,
    relatedId,
  });
}

async function creditMasterWallet(merchantId, amount, currency, reference, relatedId) {
  return record({ merchantId, wallet: 'master_wallet', type: 'wallet_topup', amount, currency, reference, relatedId });
}

async function debitMasterWallet(merchantId, amount, currency, reference, relatedId) {
  return record({
    merchantId,
    wallet: 'master_wallet',
    type: 'wallet_debit',
    amount: -Math.abs(amount),
    currency,
    reference,
    relatedId,
  });
}

module.exports = {
  record,
  getBalance,
  creditGateway,
  debitGatewayForPayout,
  creditMasterWallet,
  debitMasterWallet,
};
