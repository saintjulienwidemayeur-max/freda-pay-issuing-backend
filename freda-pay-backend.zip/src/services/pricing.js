'use strict';
const config = require('../config');

function round2(n) {
  return Math.round(n * 100) / 100;
}

function gatewayPlan(planKey) {
  return config.gatewayPlans[planKey] || config.gatewayPlans.standard;
}
function issuingPlan(planKey) {
  return config.issuingPlans[planKey] || config.issuingPlans.startup;
}

/**
 * Compute Freda Pay's Gateway transaction fee for a payment, based on the
 * merchant's chosen Gateway plan (same fee regardless of MonCash/Natcash/
 * carte - see freda-pay-landing.html "Tarifs").
 * Returns { fee, net } in the same currency as the amount (HTG).
 */
function computeGatewayFee(gatewayPlanKey, amount) {
  const cfg = gatewayPlan(gatewayPlanKey);
  const fee = round2(amount * cfg.pct + cfg.fixedHTG);
  return { fee, net: round2(amount - fee) };
}

/** Converts an HTG amount to USD at the platform's fixed rate. */
function htgToUsd(amountHtg) {
  return round2(amountHtg / config.exchangeRateHtgPerUsd);
}

/**
 * Compute the Master Wallet funding fee (topping up via MonCash/Natcash),
 * based on the merchant's Issuing plan. Returns the fee in HTG, the net HTG
 * after the fee, and the resulting USD credit.
 */
function computeWalletFundingFee(issuingPlanKey, amountHtg) {
  const cfg = issuingPlan(issuingPlanKey);
  const fee = round2(amountHtg * cfg.walletFundingPct);
  const netHtg = round2(amountHtg - fee);
  return { fee, netHtg, creditedUsd: htgToUsd(netHtg) };
}

/** Flat per-card creation fee (USD) for the merchant's Issuing plan. */
function cardCreationFee(issuingPlanKey) {
  return issuingPlan(issuingPlanKey).cardCreationUSD;
}
/** Flat per-recharge fee (USD) for the merchant's Issuing plan. */
function cardRechargeFee(issuingPlanKey) {
  return issuingPlan(issuingPlanKey).rechargeUSD;
}
/** Flat per-withdrawal fee (USD) for the merchant's Issuing plan. */
function cardWithdrawalFee(issuingPlanKey) {
  return issuingPlan(issuingPlanKey).withdrawalUSD;
}
/** Card limit for the merchant's Issuing plan (null = unlimited). */
function cardLimitFor(issuingPlanKey) {
  return issuingPlan(issuingPlanKey).cardLimit;
}

module.exports = {
  round2,
  gatewayPlan,
  issuingPlan,
  computeGatewayFee,
  computeWalletFundingFee,
  htgToUsd,
  cardCreationFee,
  cardRechargeFee,
  cardWithdrawalFee,
  cardLimitFor,
};
