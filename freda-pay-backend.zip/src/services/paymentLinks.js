'use strict';
const supabase = require('../lib/supabase');

async function create({ id, merchantId, amount, currency, description }) {
  return supabase.insert('payment_links', {
    id,
    merchant_id: merchantId,
    amount: amount != null ? amount : null,
    currency: currency || 'HTG',
    description: description || null,
    status: 'active',
  });
}

async function list(merchantId, limit, offset) {
  return supabase.select('payment_links', { merchant_id: merchantId }, { order: 'created_at.desc', limit: limit || 50, offset: offset || 0 });
}

async function getById(id) {
  return supabase.selectOne('payment_links', { id });
}

async function getByIdForMerchant(merchantId, id) {
  return supabase.selectOne('payment_links', { id, merchant_id: merchantId });
}

async function disable(merchantId, id) {
  const rows = await supabase.update('payment_links', { id, merchant_id: merchantId }, { status: 'disabled' });
  return rows && rows[0];
}

module.exports = { create, list, getById, getByIdForMerchant, disable };
