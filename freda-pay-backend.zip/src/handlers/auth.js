'use strict';
const supabase = require('../lib/supabase');
const { hashPassword, verifyPassword } = require('../utils/password');
const { generateMerchantId } = require('../utils/ids');
const jwt = require('../utils/jwt');
const config = require('../config');
const ledger = require('../services/ledger');
const otpService = require('../services/otpService');
const rateLimit = require('../utils/rateLimit');

function publicMerchant(m) {
  return {
    id: m.id,
    business_name: m.business_name,
    entity_type: m.entity_type,
    account_type: m.account_type,
    email: m.email,
    phone: m.phone,
    kyc_status: m.kyc_status,
    kyb_status: m.kyb_status,
    live_enabled: !!m.live_enabled,
    email_verified: !!m.email_verified,
    gateway_plan: m.gateway_plan || 'standard',
    issuing_plan: m.issuing_plan || 'startup',
    created_at: m.created_at,
  };
}

function issueSession(merchantId, role, userId) {
  const payload = { merchantId };
  if (role && role !== 'owner') Object.assign(payload, { role, userId }); // owner tokens stay as before
  return jwt.sign(payload, config.sessionSecret, 60 * 60 * 24 * 7); // 7 days
}

const ONBOARDING_KEYS = ['product', 'business_description', 'monthly_volume', 'monthly_cards', 'card_use_case', 'source_of_funds'];

/**
 * Keeps only the known onboarding answers, as short strings. Everything is
 * optional here (API-created accounts skip the signup wizard); the wizard
 * itself enforces which questions are required.
 */
function sanitizeOnboarding(raw) {
  if (!raw || typeof raw !== 'object') return null;
  const out = {};
  for (const k of ONBOARDING_KEYS) {
    if (typeof raw[k] === 'string' && raw[k].trim()) out[k] = raw[k].trim().slice(0, 400);
  }
  return Object.keys(out).length ? out : null;
}

async function register(ctx) {
  const { business_name, entity_type, account_type, email, phone, password, onboarding } = ctx.body || {};

  if (!business_name || !email || !password) {
    throw httpError(400, 'MISSING_FIELDS', 'business_name, email et password sont requis.');
  }
  if (String(password).length < 8) {
    throw httpError(400, 'WEAK_PASSWORD', 'Le mot de passe doit contenir au moins 8 caractères.');
  }

  const normalizedEmail = String(email).toLowerCase();
  const existing = await supabase.selectOne('merchants', { email: normalizedEmail });
  if (existing) {
    throw httpError(409, 'EMAIL_TAKEN', 'Un compte existe déjà avec cet email.');
  }

  const id = generateMerchantId();
  const merchant = await supabase.insert('merchants', {
    id,
    business_name,
    entity_type: entity_type || null,
    account_type: account_type === 'business' ? 'business' : 'individual',
    email: normalizedEmail,
    phone: phone || null,
    password_hash: hashPassword(password),
    gateway_plan: 'standard',
    issuing_plan: 'startup',
    email_verified: false,
    onboarding: sanitizeOnboarding(onboarding),
  });

  // Sandbox play money: every new account starts as sandbox (live_enabled=false),
  // so merchants can test billing, card issuance, payouts, etc. right away.
  const seed = config.sandbox.masterWalletSeedUsd;
  if (seed > 0) {
    await ledger.creditMasterWallet(id, seed, 'USD', 'sandbox-welcome-bonus', id);
  }

  // No session token yet: the account must verify its email via OTP first.
  try {
    await otpService.createAndSendOtp(merchant, 'signup');
  } catch (err) {
    // The account already exists at this point; don't fail registration just
    // because the email couldn't be sent (e.g. Brevo not configured yet in
    // this environment) - the merchant can request a resend once it's fixed.
    // eslint-disable-next-line no-console
    console.error('Failed to send signup OTP:', err.message);
  }

  return {
    status: 201,
    body: { merchant_id: id, email: normalizedEmail, email_verified: false, otp_required: true },
  };
}

async function verifyEmailOtp(ctx) {
  const { merchant_id, code } = ctx.body || {};
  if (!merchant_id || !code) {
    throw httpError(400, 'MISSING_FIELDS', 'merchant_id et code sont requis.');
  }

  const merchant = await supabase.selectOne('merchants', { id: merchant_id });
  if (!merchant) throw httpError(404, 'NOT_FOUND', 'Compte introuvable.');
  if (merchant.email_verified) {
    return { status: 200, body: { merchant: publicMerchant(merchant), session_token: issueSession(merchant.id) } };
  }

  await otpService.verifyOtp(merchant_id, code, 'signup'); // throws a specific error on any failure

  const [updated] = await supabase.update('merchants', { id: merchant_id }, { email_verified: true });
  rateLimit.reset(`login-fail:${merchant.email}`);
  return { status: 200, body: { merchant: publicMerchant(updated), session_token: issueSession(updated.id) } };
}

async function resendEmailOtp(ctx) {
  const { merchant_id } = ctx.body || {};
  if (!merchant_id) throw httpError(400, 'MISSING_FIELDS', 'merchant_id est requis.');

  const merchant = await supabase.selectOne('merchants', { id: merchant_id });
  if (!merchant) throw httpError(404, 'NOT_FOUND', 'Compte introuvable.');
  if (merchant.email_verified) {
    throw httpError(409, 'ALREADY_VERIFIED', 'Cet email est déjà vérifié.');
  }

  await otpService.resendOtp(merchant, 'signup');
  return { status: 200, body: { sent: true } };
}

const LOGIN_FAIL_LIMIT = 10;
const LOGIN_FAIL_WINDOW_MS = 15 * 60 * 1000;

async function login(ctx) {
  const { email, password } = ctx.body || {};
  if (!email || !password) {
    throw httpError(400, 'MISSING_FIELDS', 'email et password sont requis.');
  }
  const normalizedEmail = String(email).toLowerCase();
  const lockKey = `login-fail:${normalizedEmail}`;

  // Per-account lockout after repeated failures, in addition to the per-IP
  // rate limit already applied at the route level - slows down credential
  // stuffing against one specific account even from many different IPs.
  const lockState = rateLimit.isLimited(lockKey, LOGIN_FAIL_LIMIT);
  if (lockState.limited) {
    const seconds = Math.ceil(lockState.retryAfterMs / 1000);
    throw httpError(429, 'ACCOUNT_LOCKED', `Trop de tentatives échouées. Réessayez dans ${Math.ceil(seconds / 60)} minute(s).`);
  }

  const owner = await supabase.selectOne('merchants', { email: normalizedEmail });

  if (owner && verifyPassword(password, owner.password_hash)) {
    if (!owner.email_verified) {
      const err = httpError(403, 'EMAIL_NOT_VERIFIED', "Vérifiez d'abord votre adresse email avec le code envoyé à l'inscription.");
      err.details = { merchant_id: owner.id };
      throw err;
    }
    rateLimit.reset(lockKey);
    return { status: 200, body: { merchant: publicMerchant(owner), session_token: issueSession(owner.id), role: 'owner' } };
  }

  // Not an account owner: maybe a team member invited by one.
  const member = owner ? null : await supabase.selectOne('team_members', { email: normalizedEmail });
  if (member && member.status === 'active' && member.password_hash && verifyPassword(password, member.password_hash)) {
    const teamMerchant = await supabase.selectOne('merchants', { id: member.merchant_id });
    if (teamMerchant) {
      rateLimit.reset(lockKey);
      return {
        status: 200,
        body: { merchant: publicMerchant(teamMerchant), session_token: issueSession(teamMerchant.id, member.role, member.id), role: member.role },
      };
    }
  }

  rateLimit.hit(lockKey, LOGIN_FAIL_LIMIT, LOGIN_FAIL_WINDOW_MS);
  throw httpError(401, 'INVALID_CREDENTIALS', 'Email ou mot de passe incorrect.');
}

async function me(ctx) {
  const merchant = await supabase.selectOne('merchants', { id: ctx.merchantId });
  if (!merchant) throw httpError(404, 'NOT_FOUND', 'Marchand introuvable.');
  let email = merchant.email;
  if (ctx.role && ctx.role !== 'owner' && ctx.userId) {
    const member = await supabase.selectOne('team_members', { id: ctx.userId });
    if (member) email = member.email;
  }
  return { status: 200, body: { merchant: publicMerchant(merchant), user: { email, role: ctx.role || 'owner' } } };
}

function httpError(status, code, message) {
  const err = new Error(message);
  err.httpStatus = status;
  err.code = code;
  return err;
}

module.exports = { register, login, verifyEmailOtp, resendEmailOtp, me, publicMerchant, issueSession };
