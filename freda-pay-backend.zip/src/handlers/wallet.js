'use strict';
const ledger = require('../services/ledger');

async function getBalance(ctx) {
  const [gateway, masterWallet] = await Promise.all([
    ledger.getBalance(ctx.merchantId, 'gateway', 'HTG'),
    ledger.getBalance(ctx.merchantId, 'master_wallet', 'USD'),
  ]);
  return {
    status: 200,
    body: {
      gateway: { available: gateway, currency: 'HTG' },
      master_wallet: { available: masterWallet, currency: 'USD' },
    },
  };
}

module.exports = { getBalance };
