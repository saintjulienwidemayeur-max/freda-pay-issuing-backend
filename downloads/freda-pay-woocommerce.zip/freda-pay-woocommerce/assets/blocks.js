/* Freda Pay : choix MonCash / Natcash / carte dans la page de paiement en blocs de WooCommerce. */
(function () {
  var registry = window.wc && window.wc.wcBlocksRegistry;
  var wcSettings = window.wc && window.wc.wcSettings;
  var element = window.wp && window.wp.element;
  if (!registry || !wcSettings || !element) return;

  var h = element.createElement;
  var useState = element.useState;
  var useEffect = element.useEffect;
  var settings = wcSettings.getSetting('freda_pay_data', {});
  var title = settings.title || 'MonCash, Natcash ou carte';

  function Content(props) {
    var state = useState('moncash');
    var method = state[0];
    var setMethod = state[1];
    var onPaymentSetup = props.eventRegistration && props.eventRegistration.onPaymentSetup;
    var responseTypes = props.emitResponse && props.emitResponse.responseTypes;

    useEffect(function () {
      if (!onPaymentSetup) return undefined;
      return onPaymentSetup(function () {
        return {
          type: responseTypes ? responseTypes.SUCCESS : 'success',
          meta: { paymentMethodData: { freda_pay_method: method } }
        };
      });
    }, [onPaymentSetup, method]);

    function option(value, label) {
      return h('label', { key: value, style: { display: 'block', marginBottom: '6px' } },
        h('input', {
          type: 'radio',
          name: 'freda_pay_method_block',
          value: value,
          checked: method === value,
          onChange: function () { setMethod(value); }
        }),
        ' ' + label
      );
    }

    return h('div', null,
      settings.description ? h('p', null, settings.description) : null,
      option('moncash', 'MonCash'),
      option('natcash', 'Natcash'),
      option('carte', 'Carte bancaire (Visa, Mastercard)')
    );
  }

  registry.registerPaymentMethod({
    name: 'freda_pay',
    label: title,
    ariaLabel: title,
    content: h(Content, null),
    edit: h(Content, null),
    canMakePayment: function () { return true; },
    supports: { features: settings.supports || ['products'] }
  });
})();
