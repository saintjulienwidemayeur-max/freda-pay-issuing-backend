=== Freda Pay pour WooCommerce ===
Contributors: fredapay
Tags: moncash, natcash, carte, haiti, paiement, woocommerce
Requires at least: 6.0
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later

Acceptez MonCash, Natcash et la carte bancaire dans votre boutique WooCommerce avec Freda Pay Issuing.

== Description ==

Vos clients choisissent MonCash, Natcash ou carte au moment de payer. Le plugin crée le paiement,
affiche un bouton « Payer maintenant », puis confirme la commande automatiquement dès que
le paiement est reçu. Si le client ferme la page trop tôt, une vérification automatique
toutes les 5 minutes met la commande à jour.

Fonctionne avec la page de paiement classique et avec la nouvelle page de paiement en blocs.

== Installation ==

1. Extensions > Ajouter > Téléverser une extension, choisissez freda-pay-woocommerce.zip, puis Activer.
2. WooCommerce > Réglages > Paiements > Freda Pay (MonCash, Natcash) : cliquez sur Gérer.
3. Cochez Activer, collez votre clé secrète (sk_test_... ou sk_live_...) et enregistrez.
4. Passez une commande de test pour vérifier.

Votre boutique doit afficher ses prix en HTG ou en USD. MonCash et Natcash se paient en HTG, la carte
en USD : le prix de la commande est converti avec le taux défini dans les réglages (133 HTG pour
1 USD par défaut) quand sa devise est différente. Un paiement par carte (minimum 0,50 USD) crédite
votre solde Gateway USD ; l'activation de la carte en Live se demande à Freda Pay.

== Frequently Asked Questions ==

= Où trouver ma clé secrète ? =
Dans votre tableau de bord Freda Pay, rubrique Clés API.

= La commande reste « En attente de paiement » =
La commande se confirme dès que Freda Pay reçoit le paiement. Vérifiez que le cron WordPress
fonctionne (certains hébergeurs le désactivent) et que votre clé secrète est correcte.

= Le moyen de paiement n'apparaît pas =
Vérifiez que le moyen est activé, qu'une clé secrète est enregistrée et que la devise de la
boutique est HTG ou USD.

== Changelog ==

= 1.1.0 =
* Paiement par carte bancaire (Visa, Mastercard) sur une page sécurisée Freda Pay, retour automatique sur la commande.

= 1.0.0 =
* Première version : MonCash et Natcash, page de paiement classique et en blocs, confirmation automatique.
