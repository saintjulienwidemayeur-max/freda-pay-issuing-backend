<?php
/**
 * Plugin Name:       Freda Pay pour WooCommerce
 * Plugin URI:        https://www.fredapay.com
 * Description:       Acceptez les paiements MonCash et Natcash dans votre boutique WooCommerce avec Freda Pay Issuing.
 * Version:           1.1.0
 * Author:            Freda Pay LLC
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Requires Plugins:  woocommerce
 * Text Domain:       freda-pay
 * License:           GPLv2 or later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'FREDA_PAY_WC_VERSION', '1.1.0' );
define( 'FREDA_PAY_WC_FILE', __FILE__ );

/* Compatibilité : commandes HPOS et page de paiement en blocs. */
add_action(
	'before_woocommerce_init',
	function () {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', FREDA_PAY_WC_FILE, true );
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', FREDA_PAY_WC_FILE, true );
		}
	}
);

/* Enregistre la passerelle. */
add_action( 'plugins_loaded', 'freda_pay_wc_init', 11 );
function freda_pay_wc_init() {
	if ( ! class_exists( 'WC_Payment_Gateway' ) ) {
		return;
	}
	require_once __DIR__ . '/includes/class-wc-gateway-freda-pay.php';
	add_filter(
		'woocommerce_payment_gateways',
		function ( $gateways ) {
			$gateways[] = 'WC_Gateway_Freda_Pay';
			return $gateways;
		}
	);
}

/* Page de paiement en blocs (WooCommerce 8.3+). */
add_action(
	'woocommerce_blocks_payment_method_type_registration',
	function ( $registry ) {
		if ( ! class_exists( '\Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) {
			return;
		}
		require_once __DIR__ . '/includes/class-wc-freda-pay-blocks.php';
		$registry->register( new WC_Freda_Pay_Blocks() );
	}
);

/* Renvoie l'instance de la passerelle, ou null. */
function freda_pay_wc_gateway() {
	if ( ! function_exists( 'WC' ) || ! WC()->payment_gateways() ) {
		return null;
	}
	$gateways = WC()->payment_gateways()->payment_gateways();
	return isset( $gateways['freda_pay'] ) ? $gateways['freda_pay'] : null;
}

/* Vérification périodique des commandes en attente (secours si le client ferme la page). */
add_filter(
	'cron_schedules',
	function ( $schedules ) {
		$schedules['freda_pay_five_minutes'] = array(
			'interval' => 300,
			'display'  => 'Toutes les 5 minutes (Freda Pay)',
		);
		return $schedules;
	}
);

register_activation_hook(
	__FILE__,
	function () {
		if ( ! wp_next_scheduled( 'freda_pay_check_pending' ) ) {
			wp_schedule_event( time() + 300, 'freda_pay_five_minutes', 'freda_pay_check_pending' );
		}
	}
);

register_deactivation_hook(
	__FILE__,
	function () {
		wp_clear_scheduled_hook( 'freda_pay_check_pending' );
	}
);

add_action( 'freda_pay_check_pending', 'freda_pay_wc_check_pending_orders' );
function freda_pay_wc_check_pending_orders() {
	$gateway = freda_pay_wc_gateway();
	if ( ! $gateway || ! function_exists( 'wc_get_orders' ) ) {
		return;
	}
	$orders = wc_get_orders(
		array(
			'payment_method' => 'freda_pay',
			'status'         => array( 'pending', 'on-hold' ),
			'date_created'   => '>' . ( time() - DAY_IN_SECONDS ),
			'limit'          => 50,
		)
	);
	foreach ( $orders as $order ) {
		$gateway->check_order( $order );
	}
}

/* Point AJAX utilisé par la page « Merci » pour suivre le paiement en direct. */
add_action( 'wp_ajax_freda_pay_status', 'freda_pay_wc_ajax_status' );
add_action( 'wp_ajax_nopriv_freda_pay_status', 'freda_pay_wc_ajax_status' );
function freda_pay_wc_ajax_status() {
	$order_id = isset( $_GET['order_id'] ) ? absint( $_GET['order_id'] ) : 0;
	$key      = isset( $_GET['key'] ) ? sanitize_text_field( wp_unslash( $_GET['key'] ) ) : '';
	$order    = $order_id ? wc_get_order( $order_id ) : null;

	// La clé de commande prouve que la personne a le droit de voir cette commande.
	if ( ! $order || ! $key || ! hash_equals( $order->get_order_key(), $key ) ) {
		wp_send_json_error( array( 'message' => 'Commande introuvable.' ), 404 );
	}

	$gateway = freda_pay_wc_gateway();
	if ( $gateway ) {
		$gateway->check_order( $order );
		$order = wc_get_order( $order_id );
	}

	wp_send_json_success(
		array(
			'paid'   => $order->is_paid(),
			'status' => $order->get_status(),
		)
	);
}
