<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Passerelle de paiement Freda Pay (MonCash / Natcash / carte bancaire) pour WooCommerce.
 *
 * Parcours :
 * 1. Le client choisit MonCash, Natcash ou carte et valide sa commande.
 * 2. Le plugin crée le paiement via POST /v1/payments (côté serveur, clé secrète).
 * 3. La page « Merci » affiche le bouton « Payer maintenant » (checkout_url) et suit le statut.
 *    Pour la carte (USD), checkout_url est la page de paiement sécurisée de Freda Pay, qui ramène ensuite le client sur la commande (return_url).
 * 4. Dès que GET /v1/payments/:id renvoie « succeeded », la commande est marquée payée.
 *    Une tâche planifiée vérifie aussi les commandes en attente toutes les 5 minutes.
 */
class WC_Gateway_Freda_Pay extends WC_Payment_Gateway {

	/** @var string */
	protected $api_base_url;
	/** @var string */
	protected $secret_key;
	/** @var float */
	protected $usd_rate;

	public function __construct() {
		$this->id                 = 'freda_pay';
		$this->icon               = '';
		$this->has_fields         = true;
		$this->method_title       = 'Freda Pay (MonCash, Natcash, carte)';
		$this->method_description = 'Encaissez vos commandes par MonCash, Natcash et carte bancaire avec Freda Pay Issuing. Créez votre clé secrète dans le tableau de bord Freda Pay, rubrique « Clés API ».';
		$this->supports           = array( 'products' );

		$this->init_form_fields();
		$this->init_settings();

		$this->title        = $this->get_option( 'title' );
		$this->description  = $this->get_option( 'description' );
		$this->enabled      = $this->get_option( 'enabled' );
		$this->api_base_url = untrailingslashit( $this->get_option( 'api_base_url', 'https://api.fredapay.com' ) );
		$this->secret_key   = trim( (string) $this->get_option( 'secret_key' ) );
		$this->usd_rate     = (float) $this->get_option( 'usd_rate', 133 );

		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
		add_action( 'woocommerce_thankyou_' . $this->id, array( $this, 'thankyou_page' ) );
	}

	public function init_form_fields() {
		$this->form_fields = array(
			'enabled'      => array(
				'title'   => 'Activer',
				'type'    => 'checkbox',
				'label'   => 'Activer Freda Pay sur la page de paiement',
				'default' => 'no',
			),
			'title'        => array(
				'title'   => 'Titre affiché au client',
				'type'    => 'text',
				'default' => 'MonCash, Natcash ou carte',
			),
			'description'  => array(
				'title'   => 'Description affichée au client',
				'type'    => 'textarea',
				'default' => 'Payez en toute sécurité avec MonCash, Natcash ou carte bancaire via Freda Pay.',
			),
			'secret_key'   => array(
				'title'       => 'Clé secrète',
				'type'        => 'password',
				'description' => 'Commence par sk_test_ ou sk_live_. Ne la partagez jamais.',
				'default'     => '',
			),
			'api_base_url' => array(
				'title'       => 'Adresse de l\'API',
				'type'        => 'text',
				'description' => 'Laissez la valeur par défaut sauf indication contraire de Freda Pay.',
				'default'     => 'https://api.fredapay.com',
			),
			'usd_rate'     => array(
				'title'       => 'Taux HTG pour 1 USD',
				'type'        => 'number',
				'description' => 'Sert à convertir : MonCash et Natcash se paient en HTG, la carte en USD. Le prix de la commande est converti avec ce taux quand sa devise est différente.',
				'default'     => '133',
				'custom_attributes' => array( 'step' => '0.01', 'min' => '1' ),
			),
		);
	}

	public function is_available() {
		if ( ! parent::is_available() || '' === $this->secret_key ) {
			return false;
		}
		return in_array( get_woocommerce_currency(), array( 'HTG', 'USD' ), true );
	}

	/* Choix de la méthode sur la page de paiement classique. */
	public function payment_fields() {
		if ( $this->description ) {
			echo wpautop( wp_kses_post( $this->description ) );
		}
		echo '<fieldset id="freda-pay-methods" style="border:0;padding:0;margin:8px 0 0">';
		echo '<label style="display:block;margin-bottom:6px"><input type="radio" name="freda_pay_method" value="moncash" checked> MonCash</label>';
		echo '<label style="display:block;margin-bottom:6px"><input type="radio" name="freda_pay_method" value="natcash"> Natcash</label>';
		echo '<label style="display:block"><input type="radio" name="freda_pay_method" value="carte"> Carte bancaire (Visa, Mastercard)</label>';
		echo '</fieldset>';
	}

	protected function selected_method() {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- WooCommerce vérifie le nonce du formulaire de commande.
		$method = isset( $_POST['freda_pay_method'] ) ? sanitize_text_field( wp_unslash( $_POST['freda_pay_method'] ) ) : 'moncash';
		return in_array( $method, array( 'moncash', 'natcash', 'carte' ), true ) ? $method : '';
	}

	public function validate_fields() {
		if ( '' === $this->selected_method() ) {
			wc_add_notice( 'Choisissez MonCash, Natcash ou carte.', 'error' );
			return false;
		}
		return true;
	}

	protected function amount_htg( $order ) {
		$total = (float) $order->get_total();
		if ( 'USD' === $order->get_currency() ) {
			$total = $total * $this->usd_rate;
		}
		return round( $total, 2 );
	}

	/** Montant en USD pour un paiement par carte (la carte se paie toujours en USD). */
	protected function amount_usd( $order ) {
		$total = (float) $order->get_total();
		if ( 'USD' !== $order->get_currency() ) {
			$total = $total / max( 1.0, $this->usd_rate );
		}
		return round( $total, 2 );
	}

	/**
	 * Appel à l'API Freda Pay. Retourne array( 'code' => int, 'data' => array|null, 'error' => string|null ).
	 */
	protected function api( $http_method, $path, $body = null ) {
		$args = array(
			'method'  => $http_method,
			'timeout' => 30,
			'headers' => array(
				'Authorization' => 'Bearer ' . $this->secret_key,
				'Content-Type'  => 'application/json',
				'User-Agent'    => 'FredaPay-WooCommerce/' . FREDA_PAY_WC_VERSION,
			),
		);
		if ( null !== $body ) {
			$args['body'] = wp_json_encode( $body );
		}

		$response = wp_remote_request( $this->api_base_url . $path, $args );
		if ( is_wp_error( $response ) ) {
			return array( 'code' => 0, 'data' => null, 'error' => $response->get_error_message() );
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		$error = null;
		if ( $code >= 400 ) {
			$error = ( is_array( $data ) && isset( $data['error']['message'] ) ) ? $data['error']['message'] : 'Erreur Freda Pay (HTTP ' . $code . ').';
		}
		return array( 'code' => $code, 'data' => is_array( $data ) ? $data : null, 'error' => $error );
	}

	public function process_payment( $order_id ) {
		$order  = wc_get_order( $order_id );
		$method = $this->selected_method();
		$is_card  = ( 'carte' === $method );
		$currency = $is_card ? 'USD' : 'HTG';
		$amount   = $is_card ? $this->amount_usd( $order ) : $this->amount_htg( $order );

		if ( '' === $method ) {
			wc_add_notice( 'Choisissez MonCash, Natcash ou carte.', 'error' );
			return array( 'result' => 'failure' );
		}
		if ( ! $is_card && $amount < 20 ) {
			wc_add_notice( 'Le montant minimum pour MonCash et Natcash est de 20 HTG.', 'error' );
			return array( 'result' => 'failure' );
		}
		if ( $is_card && $amount < 0.5 ) {
			wc_add_notice( 'Le montant minimum pour un paiement par carte est de 0,50 USD.', 'error' );
			return array( 'result' => 'failure' );
		}

		// Une référence unique par tentative : un nouvel essai ne réutilise pas un paiement échoué.
		$attempt   = (int) $order->get_meta( '_freda_pay_attempt' ) + 1;
		$reference = 'WC-' . $order->get_id() . '-' . $attempt;

		$result = $this->api(
			'POST',
			'/v1/payments',
			array_merge(
				array(
					'amount'    => $amount,
					'currency'  => $currency,
					'method'    => $method,
					'reference' => $reference,
				),
				// Carte : la page sécurisée de Freda Pay ramène le client sur la commande une fois le paiement fait.
				$is_card ? array(
					'return_url'     => $this->get_return_url( $order ),
					'customer_name'  => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
					'customer_email' => $order->get_billing_email(),
				) : array()
			)
		);

		if ( $result['error'] || empty( $result['data']['id'] ) ) {
			$message = $result['error'] ? $result['error'] : 'Réponse inattendue de Freda Pay.';
			$order->add_order_note( 'Échec de création du paiement Freda Pay : ' . $message );
			wc_add_notice( 'Le paiement n\'a pas pu être créé : ' . esc_html( $message ), 'error' );
			return array( 'result' => 'failure' );
		}

		$payment = $result['data'];
		$order->update_meta_data( '_freda_pay_attempt', $attempt );
		$order->update_meta_data( '_freda_pay_payment_id', sanitize_text_field( $payment['id'] ) );
		$order->update_meta_data( '_freda_pay_checkout_url', isset( $payment['checkout_url'] ) ? esc_url_raw( $payment['checkout_url'] ) : '' );
		$order->update_meta_data( '_freda_pay_amount', $amount );
		$order->update_meta_data( '_freda_pay_currency', $currency );
		$order->update_meta_data( '_freda_pay_method', $method );
		$order->set_transaction_id( sanitize_text_field( $payment['id'] ) );
		$order->save();

		$order->update_status( 'pending', sprintf( 'Paiement Freda Pay %s créé (%s, %s %s). En attente du client.', $payment['id'], $method, $amount, $currency ) );

		if ( WC()->cart ) {
			WC()->cart->empty_cart();
		}

		return array(
			'result'   => 'success',
			'redirect' => $this->get_return_url( $order ),
		);
	}

	/**
	 * Interroge Freda Pay et met à jour la commande. Sans effet si déjà payée.
	 */
	public function check_order( $order ) {
		if ( ! $order || $order->is_paid() ) {
			return;
		}
		$payment_id = $order->get_meta( '_freda_pay_payment_id' );
		if ( ! $payment_id ) {
			return;
		}

		$result = $this->api( 'GET', '/v1/payments/' . rawurlencode( $payment_id ) );
		if ( $result['error'] || empty( $result['data']['status'] ) ) {
			return; // Erreur réseau : on réessaiera plus tard.
		}
		$payment = $result['data'];

		if ( 'succeeded' === $payment['status'] ) {
			$expected = (float) $order->get_meta( '_freda_pay_amount' );
			$received = isset( $payment['amount'] ) ? (float) $payment['amount'] : 0.0;
			if ( abs( $expected - $received ) > 0.01 ) {
				$cur = $order->get_meta( '_freda_pay_currency' ) ? $order->get_meta( '_freda_pay_currency' ) : 'HTG';
				$order->update_status( 'on-hold', sprintf( 'Montant Freda Pay différent : attendu %s %s, reçu %s %s. Vérifiez avant de livrer.', $expected, $cur, $received, $cur ) );
				return;
			}
			$order->payment_complete( $payment_id );
			$order->add_order_note(
				sprintf(
					'Paiement Freda Pay confirmé. Frais : %s %s. Net crédité : %s %s.',
					isset( $payment['fee'] ) ? $payment['fee'] : '?',
					$order->get_meta( '_freda_pay_currency' ) ? $order->get_meta( '_freda_pay_currency' ) : 'HTG',
					isset( $payment['net_amount'] ) ? $payment['net_amount'] : '?',
					$order->get_meta( '_freda_pay_currency' ) ? $order->get_meta( '_freda_pay_currency' ) : 'HTG'
				)
			);
		} elseif ( 'failed' === $payment['status'] ) {
			$order->update_status( 'failed', 'Le paiement Freda Pay a échoué.' );
		}
	}

	/* Page « Merci » : bouton de paiement + suivi en direct. */
	public function thankyou_page( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}
		$this->check_order( $order );
		$order = wc_get_order( $order_id );

		if ( $order->is_paid() ) {
			echo '<div class="woocommerce-message" role="status">Votre paiement a été confirmé. Merci !</div>';
			return;
		}
		if ( 'failed' === $order->get_status() ) {
			echo '<div class="woocommerce-error" role="alert">Le paiement n\'a pas abouti. Vous pouvez réessayer depuis votre compte ou contacter la boutique.</div>';
			return;
		}

		$checkout_url = $order->get_meta( '_freda_pay_checkout_url' );
		$is_card      = ( 'carte' === $order->get_meta( '_freda_pay_method' ) );
		$ajax_url     = add_query_arg(
			array(
				'action'   => 'freda_pay_status',
				'order_id' => $order->get_id(),
				'key'      => $order->get_order_key(),
			),
			admin_url( 'admin-ajax.php' )
		);
		?>
		<section id="freda-pay-box" style="border:1px solid #ececec;border-radius:12px;padding:20px;margin:20px 0">
			<h2 style="margin-top:0">Finalisez votre paiement</h2>
			<?php if ( $checkout_url ) : ?>
				<?php if ( $is_card ) : ?>
					<p>Cliquez sur le bouton pour entrer les informations de votre carte sur la page de paiement sécurisée. Vous reviendrez ensuite ici automatiquement.</p>
					<p><a class="button alt" href="<?php echo esc_url( $checkout_url ); ?>">Payer par carte</a></p>
				<?php else : ?>
					<p>Cliquez sur le bouton, confirmez le paiement sur votre téléphone, puis revenez sur cette page. Elle se mettra à jour toute seule.</p>
					<p><a class="button alt" href="<?php echo esc_url( $checkout_url ); ?>" target="_blank" rel="noopener">Payer maintenant</a></p>
				<?php endif; ?>
			<?php else : ?>
				<p>Confirmez le paiement sur votre téléphone. Cette page se mettra à jour toute seule.</p>
			<?php endif; ?>
			<p id="freda-pay-status" aria-live="polite" style="color:#6b5f66;margin-bottom:0">En attente de confirmation…</p>
		</section>
		<script>
		(function () {
			var url = <?php echo wp_json_encode( $ajax_url ); ?>;
			var tries = 0;
			function check() {
				tries++;
				fetch(url, { credentials: 'same-origin' })
					.then(function (r) { return r.json(); })
					.then(function (res) {
						if (res && res.success && res.data.paid) {
							document.getElementById('freda-pay-status').textContent = 'Paiement confirmé. Actualisation…';
							window.location.reload();
						} else if (res && res.success && res.data.status === 'failed') {
							document.getElementById('freda-pay-status').textContent = 'Le paiement a échoué.';
						} else if (tries < 120) {
							setTimeout(check, 5000);
						} else {
							document.getElementById('freda-pay-status').textContent = 'Toujours en attente. Si vous avez payé, la commande sera confirmée automatiquement dans quelques minutes.';
						}
					})
					.catch(function () { if (tries < 120) { setTimeout(check, 8000); } });
			}
			setTimeout(check, 5000);
		})();
		</script>
		<?php
	}
}
