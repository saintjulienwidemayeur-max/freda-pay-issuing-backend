<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

/**
 * Intégration de Freda Pay dans la page de paiement en blocs de WooCommerce.
 */
final class WC_Freda_Pay_Blocks extends AbstractPaymentMethodType {

	protected $name = 'freda_pay';

	public function initialize() {
		$this->settings = get_option( 'woocommerce_freda_pay_settings', array() );
	}

	public function is_active() {
		return ! empty( $this->settings['enabled'] ) && 'yes' === $this->settings['enabled'] && ! empty( $this->settings['secret_key'] );
	}

	public function get_payment_method_script_handles() {
		wp_register_script(
			'freda-pay-blocks',
			plugins_url( 'assets/blocks.js', FREDA_PAY_WC_FILE ),
			array( 'wc-blocks-registry', 'wc-settings', 'wp-element' ),
			FREDA_PAY_WC_VERSION,
			true
		);
		return array( 'freda-pay-blocks' );
	}

	public function get_payment_method_data() {
		return array(
			'title'       => isset( $this->settings['title'] ) ? $this->settings['title'] : 'MonCash, Natcash ou carte',
			'description' => isset( $this->settings['description'] ) ? $this->settings['description'] : '',
			'supports'    => array( 'products' ),
		);
	}
}
