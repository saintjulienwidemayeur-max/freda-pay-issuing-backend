/**
 * Freda Pay pour Wix (Velo) - fichier BACKEND.
 * À placer dans : Backend > fredaPay.web.js
 *
 * La clé secrète est lue dans le Gestionnaire de secrets de Wix (nom : FREDA_SECRET_KEY).
 * Elle ne quitte jamais le serveur Wix.
 */
import { Permissions, webMethod } from 'wix-web-module';
import { getSecret } from 'wix-secrets-backend';
import { fetch } from 'wix-fetch';

const API_BASE = 'https://api.fredapay.com';

// MonCash et Natcash se paient en HTG, la carte en USD : le prix HTG du produit est converti avec ce taux.
const USD_RATE = 133;

/*
 * Vos produits et leur prix en HTG.
 * Le prix est fixé ICI, côté serveur : un visiteur ne peut pas le modifier depuis son navigateur.
 */
const PRODUCTS = {
  'abonnement-mensuel': { name: 'Abonnement mensuel', price: 1500 },
  'formation-complete': { name: 'Formation complète', price: 6500 },
};

async function freda(path, options = {}) {
  const secretKey = await getSecret('FREDA_SECRET_KEY');
  const response = await fetch(API_BASE + path, {
    method: options.method || 'GET',
    headers: {
      Authorization: 'Bearer ' + secretKey,
      'Content-Type': 'application/json',
    },
    body: options.body ? JSON.stringify(options.body) : undefined,
  });
  const data = await response.json();
  if (!response.ok) {
    const message = (data && data.error && data.error.message) || 'Erreur Freda Pay (HTTP ' + response.status + ').';
    throw new Error(message);
  }
  return data;
}

/**
 * Crée un paiement pour un produit de la liste PRODUCTS.
 * method : 'moncash', 'natcash' ou 'carte'.
 * returnUrl (facultatif, https) : pour la carte, la page sécurisée y ramène le client après le paiement.
 * Renvoie { id, checkout_url, amount, currency } au code de la page.
 */
export const createFredaPayment = webMethod(Permissions.Anyone, async (productId, method, returnUrl) => {
  const product = PRODUCTS[productId];
  if (!product) throw new Error('Produit inconnu.');
  if (method !== 'moncash' && method !== 'natcash' && method !== 'carte') throw new Error('Choisissez MonCash, Natcash ou carte.');

  const reference = 'WIX-' + productId + '-' + Date.now();
  const card = method === 'carte';
  const body = card
    ? { amount: Math.round((product.price / USD_RATE) * 100) / 100, currency: 'USD', method, reference }
    : { amount: product.price, currency: 'HTG', method, reference };
  if (card && typeof returnUrl === 'string' && returnUrl.indexOf('https://') === 0) body.return_url = returnUrl;

  const payment = await freda('/v1/payments', { method: 'POST', body });

  return { id: payment.id, checkout_url: payment.checkout_url, amount: payment.amount, currency: payment.currency };
});

/**
 * Renvoie le statut d'un paiement : 'pending', 'succeeded' ou 'failed'.
 */
export const checkFredaPayment = webMethod(Permissions.Anyone, async (paymentId) => {
  if (typeof paymentId !== 'string' || !/^pay_[a-z0-9]+$/i.test(paymentId)) {
    throw new Error('Identifiant de paiement invalide.');
  }
  const payment = await freda('/v1/payments/' + encodeURIComponent(paymentId));
  return { status: payment.status, amount: payment.amount };
});
