/**
 * Freda Pay pour Wix (Velo) - CODE DE LA PAGE.
 * À coller dans le panneau de code de la page qui contient les éléments suivants :
 *   #payMoncashButton  bouton « Payer avec MonCash »
 *   #payNatcashButton  bouton « Payer avec Natcash »
 *   #payCardButton     bouton « Payer par carte » (facultatif : sans lui, la carte n'est pas proposée)
 *   #continueButton    bouton « Continuer vers le paiement » (masqué au départ)
 *   #statusText        texte qui affiche l'état du paiement
 * Changez PRODUCT_ID pour un identifiant présent dans PRODUCTS (fichier backend).
 */
import wixLocation from 'wix-location';
import { createFredaPayment, checkFredaPayment } from 'backend/fredaPay.web';

const PRODUCT_ID = 'abonnement-mensuel';
let pollTimer = null;

$w.onReady(function () {
  $w('#continueButton').hide();
  $w('#payMoncashButton').onClick(() => startPayment('moncash'));
  $w('#payNatcashButton').onClick(() => startPayment('natcash'));
  withElement('#payCardButton', (el) => el.onClick(() => startPayment('carte')));
});

async function startPayment(method) {
  setButtonsEnabled(false);
  $w('#statusText').text = 'Création du paiement…';
  try {
    // Carte : la page sécurisée ramène le client sur cette page après le paiement.
    const payment = await createFredaPayment(PRODUCT_ID, method, wixLocation.url);

    // Le bouton ouvre la page de paiement : MonCash / Natcash dans un nouvel onglet, la carte dans la même fenêtre.
    $w('#continueButton').link = payment.checkout_url;
    $w('#continueButton').target = method === 'carte' ? '_self' : '_blank';
    $w('#continueButton').show();
    $w('#statusText').text = method === 'carte'
      ? 'Cliquez sur « Continuer vers le paiement » pour entrer votre carte sur la page sécurisée.'
      : 'Cliquez sur « Continuer vers le paiement », confirmez sur votre téléphone, puis revenez ici.';

    watchPayment(payment.id, 0);
  } catch (err) {
    $w('#statusText').text = 'Le paiement n\'a pas pu être créé : ' + err.message;
    setButtonsEnabled(true);
  }
}

function watchPayment(paymentId, tries) {
  clearTimeout(pollTimer);
  if (tries > 120) {
    $w('#statusText').text = 'Toujours en attente. Si vous avez payé, contactez-nous avec votre numéro de transaction.';
    setButtonsEnabled(true);
    return;
  }
  pollTimer = setTimeout(async () => {
    try {
      const result = await checkFredaPayment(paymentId);
      if (result.status === 'succeeded') {
        $w('#continueButton').hide();
        $w('#statusText').text = 'Paiement confirmé. Merci !';
        // Ici : débloquez le contenu, envoyez un e-mail, enregistrez la commande…
        return;
      }
      if (result.status === 'failed') {
        $w('#continueButton').hide();
        $w('#statusText').text = 'Le paiement a échoué. Vous pouvez réessayer.';
        setButtonsEnabled(true);
        return;
      }
    } catch (err) {
      // Erreur réseau passagère : on réessaie au prochain tour.
    }
    watchPayment(paymentId, tries + 1);
  }, 5000);
}

/** Le bouton carte est facultatif : s'il n'est pas sur la page, on l'ignore. */
function withElement(id, fn) {
  try {
    const el = $w(id);
    if (el && el.rendered !== false) fn(el);
  } catch (err) {
    // élément absent de la page
  }
}

function setButtonsEnabled(enabled) {
  const buttons = ['#payMoncashButton', '#payNatcashButton', '#payCardButton'];
  buttons.forEach((id) => withElement(id, (el) => (enabled ? el.enable() : el.disable())));
}
