# Freda Pay pour Wix

Deux façons d'encaisser MonCash, Natcash et la carte bancaire sur un site Wix.

## Option 1 : bouton de paiement (sans code, 2 minutes)

1. Dans le tableau de bord Freda Pay, ouvrez « Liens de paiement » et créez un lien.
2. Dans l'éditeur Wix : Ajouter > Intégrer du code > Intégrer HTML.
3. Collez ce code en remplaçant `lnk_VOTRE_LIEN` :

```html
<div data-freda-link="lnk_VOTRE_LIEN"></div>
<script src="https://pay.fredapay.com/freda-button.js" async></script>
```

Idéal pour un prix fixe, un don ou une facture. Le même lien accepte MonCash, Natcash et la carte : le client choisit.

## Option 2 : intégration Velo (montant de chaque commande)

À utiliser si vous voulez créer un paiement par produit et savoir, sur votre page, quand il est payé.

### 1. Activez le mode développeur
Dans l'éditeur Wix, activez « Mode Dev » (Velo).

### 2. Enregistrez votre clé secrète
Tableau de bord du site > Développeurs > Gestionnaire de secrets > Stocker un secret.
- Nom : `FREDA_SECRET_KEY`
- Valeur : votre clé `sk_test_...` (puis `sk_live_...` en production)

Ne collez jamais la clé directement dans le code.

### 3. Ajoutez le fichier backend
Dans le panneau Code, section Backend, créez le fichier `fredaPay.web.js` et collez le contenu de
`backend/fredaPay.web.js`. Modifiez la liste `PRODUCTS` avec vos produits et leurs prix en HTG.

### 4. Préparez la page
Ajoutez sur votre page :
- un bouton avec l'ID `payMoncashButton` (« Payer avec MonCash »)
- un bouton avec l'ID `payNatcashButton` (« Payer avec Natcash »)
- un bouton avec l'ID `payCardButton` (« Payer par carte », facultatif)
- un bouton avec l'ID `continueButton` (« Continuer vers le paiement »)
- un texte avec l'ID `statusText`

Pour changer l'ID d'un élément : sélectionnez-le, puis modifiez le champ ID dans le panneau Propriétés.

### 5. Ajoutez le code de la page
Collez le contenu de `page-code/page.js` dans le code de la page. Remplacez `PRODUCT_ID` par un
identifiant de votre liste `PRODUCTS`.

### 6. Testez
Publiez ou prévisualisez le site, cliquez sur un bouton de paiement, puis sur « Continuer vers le
paiement ». Après confirmation sur le téléphone, le texte affiche « Paiement confirmé ».

## Paiement par carte
La carte se paie en USD : le prix HTG de votre produit est converti avec `USD_RATE` (133 par défaut, en
haut du fichier backend). Le client entre sa carte sur une page sécurisée Freda Pay, puis revient sur votre
page, qui affiche « Paiement confirmé ». Le montant minimum est de 0,50 USD. En mode Live, la carte doit
d'abord être activée sur votre compte Freda Pay. L'argent reçu par carte arrive sur votre solde Gateway USD.

## Pourquoi le prix est dans le fichier backend
Le code d'une page Wix s'exécute dans le navigateur du visiteur, qui peut le modifier. En fixant le
prix côté serveur, personne ne peut payer 20 HTG pour un produit à 6 500 HTG.

## Besoin d'aide ?
issuing@fredapay.com
