<?php

declare(strict_types=1);

namespace FredaPay\Issuing\Tests;

use FredaPay\Issuing\Transport;
use PHPUnit\Framework\TestCase;

final class TransportTest extends TestCase
{
    public function testBuildQueryReturnsEmptyStringForNoParams(): void
    {
        $transport = new Transport('sk_test_mock', 'http://localhost:9999/v1');
        self::assertSame('', $transport->buildQuery([]));
    }

    public function testBuildQueryOmitsNullValues(): void
    {
        $transport = new Transport('sk_test_mock', 'http://localhost:9999/v1');
        $query = $transport->buildQuery(['page' => 2, 'page_size' => null]);
        self::assertSame('?page=2', $query);
    }

    public function testBuildQueryEncodesMultipleParams(): void
    {
        $transport = new Transport('sk_test_mock', 'http://localhost:9999/v1');
        $query = $transport->buildQuery(['page' => 1, 'page_size' => 20]);
        self::assertSame('?page=1&page_size=20', $query);
    }
}
