<?php

declare(strict_types=1);

namespace FredaPay\Issuing\Tests;

use FredaPay\Issuing\WebhookSignature;
use PHPUnit\Framework\TestCase;

final class WebhookSignatureTest extends TestCase
{
    private const SECRET = 'whsec_test123';

    private function sign(string $body, string $secret = self::SECRET): string
    {
        return 'sha256=' . hash_hmac('sha256', $body, $secret);
    }

    public function testAcceptsACorrectlySignedPayload(): void
    {
        $body = json_encode(['event' => 'payment.succeeded']);
        $signature = $this->sign($body);

        self::assertTrue(WebhookSignature::verify($body, $signature, self::SECRET));
    }

    public function testRejectsATamperedPayload(): void
    {
        $body = json_encode(['event' => 'payment.succeeded']);
        $signature = $this->sign($body);

        self::assertFalse(WebhookSignature::verify($body . 'tampered', $signature, self::SECRET));
    }

    public function testRejectsAWrongSecret(): void
    {
        $body = json_encode(['event' => 'payment.succeeded']);
        $signature = $this->sign($body);

        self::assertFalse(WebhookSignature::verify($body, $signature, 'whsec_different'));
    }

    public function testRejectsAMalformedHeader(): void
    {
        self::assertFalse(WebhookSignature::verify('body', 'not-a-real-signature', 'secret'));
        self::assertFalse(WebhookSignature::verify('body', '', 'secret'));
    }

    public function testRejectsAnEmptyBodyMismatch(): void
    {
        $signature = $this->sign('some-body');
        self::assertFalse(WebhookSignature::verify('', $signature, self::SECRET));
    }
}
