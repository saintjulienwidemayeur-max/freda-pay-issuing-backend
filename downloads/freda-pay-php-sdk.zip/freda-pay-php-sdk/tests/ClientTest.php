<?php

declare(strict_types=1);

namespace FredaPay\Issuing\Tests;

use FredaPay\Issuing\Client;
use FredaPay\Issuing\Resources\Balance;
use FredaPay\Issuing\Resources\Cards;
use FredaPay\Issuing\Resources\HolderProfile;
use FredaPay\Issuing\Resources\Payments;
use FredaPay\Issuing\Resources\Payouts;
use FredaPay\Issuing\Resources\Webhooks;
use PHPUnit\Framework\TestCase;

final class ClientTest extends TestCase
{
    public function testThrowsWhenNoApiKeyIsGiven(): void
    {
        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessageMatches('/apiKey is required/');

        new Client('');
    }

    public function testExposesEveryResourceOnceConstructed(): void
    {
        $client = new Client('sk_test_mock');

        self::assertInstanceOf(Payments::class, $client->payments);
        self::assertInstanceOf(Payouts::class, $client->payouts);
        self::assertInstanceOf(Balance::class, $client->balance);
        self::assertInstanceOf(Cards::class, $client->cards);
        self::assertInstanceOf(Webhooks::class, $client->webhooks);
        self::assertInstanceOf(HolderProfile::class, $client->cards->holderProfile);
    }

    public function testAcceptsACustomBaseUrl(): void
    {
        // Constructing with a custom base URL should not throw - the real
        // request-sending path is covered by TransportTest via buildQuery(),
        // since exercising a live HTTP call is out of scope for a unit test.
        $client = new Client('sk_test_mock', 'http://localhost:9999/v1');
        self::assertInstanceOf(Client::class, $client);
    }
}
