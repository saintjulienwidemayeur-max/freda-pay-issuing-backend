# freda-pay/issuing (PHP)

SDK PHP officiel pour l'API Freda Pay Issuing (paiements MonCash/Natcash/carte,
retraits, cartes virtuelles Visa/Mastercard, webhooks) en Haïti.

## Installation

```bash
composer require freda-pay/issuing
```

Nécessite PHP 7.4+ avec les extensions `json` et `curl` (activées par défaut
dans la plupart des hébergements, y compris mutualisés).

## Démarrage rapide

```php
<?php
require 'vendor/autoload.php';

use FredaPay\Issuing\Client;

$freda = new Client(getenv('FREDA_SECRET_KEY')); // sk_test_... ou sk_live_...

$payment = $freda->payments->create([
    'amount' => 1000,
    'method' => 'moncash',
    'reference' => 'CMD-1001',
]);

echo $payment['checkout_url']; // redirigez votre client ici

// Plus tard, confirmez depuis votre serveur :
$confirmed = $freda->payments->get($payment['id']);
if ($confirmed['status'] === 'succeeded') {
    // livrez la commande
}
```

### Paiement par carte (USD)

```php
$payment = $freda->payments->create([
    'amount' => 25, 'currency' => 'USD', 'method' => 'carte', 'reference' => 'CMD-1002',
    'customer_name' => 'Marie Client',
    'return_url' => 'https://votre-site.com/commande/1002', // la page sécurisée y ramène le client
]);
// Redirigez le client vers $payment['checkout_url'] (page de carte sécurisée Freda Pay).
// Confirmez toujours côté serveur (webhook payment.succeeded ou payments->get) avant de livrer.
```

Un paiement par carte crédite le solde `gateway_usd` (USD), frais déduits. Un paiement refusé déclenche `payment.failed`.

## Cartes virtuelles

```php
$card = $freda->cards->create([
    'reference' => 'CARD-001',
    'kind' => 'business',
    'brand' => 'VISA',
    'amount' => 20,
    'business_name' => 'Boutique Lakay',
]);

// La création est asynchrone : attendez que le statut devienne 'active'.
$current = $card;
while ($current['status'] === 'pending') {
    sleep(3);
    $current = $freda->cards->get($card['id']);
}

$freda->cards->fund($card['id'], 10, 'FUND-001'); // 3rd argument: idempotency reference, safe to replay

// Numéro complet, CVV, expiration - réservé au titulaire du compte.
$details = $freda->cards->reveal($card['id']);
```

## Titulaires (cartes individuelles)

```php
$res = $freda->cards->holderProfile->create([
    'firstName' => 'Rose', 'lastName' => 'Lakay', 'email' => 'rose@example.com',
    'country' => 'HT', 'dob' => '1990-05-12', 'identificationNumber' => 'ID123456',
    'identity' => ['type' => 'PASSPORT', 'number' => 'P1234567', 'imageUrl' => 'data:image/jpeg;base64,/9j/4AAQ...' /* or a direct https link to the image */],
    'phoneShortCode' => '+509', 'phoneNumber' => '37001234',
    'address' => ['street' => '12 Rue Example', 'city' => 'Port-au-Prince', 'state' => 'Ouest', 'postalCode' => 'HT6110', 'country' => 'HT'],
]);
$freda->cards->create(['reference' => 'CARD-002', 'kind' => 'individual', 'amount' => 20, 'holder_id' => $res['holder']['id']]);
```

## Webhooks

```php
<?php
require 'vendor/autoload.php';

use FredaPay\Issuing\WebhookSignature;

$rawBody = file_get_contents('php://input');
$signature = $_SERVER['HTTP_X_FREDA_SIGNATURE'] ?? '';
$secret = getenv('FREDA_WEBHOOK_SECRET');

if (!WebhookSignature::verify($rawBody, $signature, $secret)) {
    http_response_code(401);
    exit;
}

$event = json_decode($rawBody, true);
switch ($event['event']) {
    case 'payment.succeeded':
        // livrez la commande $event['data']['reference']
        break;
    case 'card.created':
        // notifiez l'utilisateur que sa carte est prête
        break;
}

http_response_code(200);
```

Utilisez toujours `file_get_contents('php://input')` (le corps brut) pour la
vérification de signature : un corps re-encodé ne redonne pas les mêmes octets.

## Gestion des erreurs

Chaque appel qui échoue lève une `FredaPayException` avec le même `code` et
`message` que l'API :

```php
use FredaPay\Issuing\FredaPayException;

try {
    $freda->payouts->create([
        'amount' => 500,
        'method' => 'moncash',
        'recipient' => '509...',
        'reference' => 'P-1',
    ]);
} catch (FredaPayException $e) {
    echo $e->code;    // ex: INSUFFICIENT_BALANCE
    echo $e->message;
}
```

## Référence complète

Voir [api.fredapay.com/docs](https://issuing.fredapay.com/docs) et la
[spec OpenAPI](https://api.fredapay.com/openapi.yaml).

## Tests

```bash
composer install
composer test
```

## Licence

MIT
