<?php

declare(strict_types=1);

namespace FredaPay\Issuing;

use FredaPay\Issuing\Resources\Balance;
use FredaPay\Issuing\Resources\Cards;
use FredaPay\Issuing\Resources\Payments;
use FredaPay\Issuing\Resources\Payouts;
use FredaPay\Issuing\Resources\Webhooks;

class Client
{
    public const DEFAULT_BASE_URL = 'https://api.fredapay.com/v1';

    /** @var Payments */
    public $payments;

    /** @var Payouts */
    public $payouts;

    /** @var Balance */
    public $balance;

    /** @var Cards */
    public $cards;

    /** @var Webhooks */
    public $webhooks;

    /**
     * @param string $apiKey Your sk_test_... or sk_live_... secret key.
     * @param string $baseUrl
     */
    public function __construct(string $apiKey, string $baseUrl = self::DEFAULT_BASE_URL)
    {
        if ($apiKey === '') {
            throw new \InvalidArgumentException('FredaPay: apiKey is required (sk_test_... or sk_live_...).');
        }

        $transport = new Transport($apiKey, $baseUrl);

        $this->payments = new Payments($transport);
        $this->payouts = new Payouts($transport);
        $this->balance = new Balance($transport);
        $this->cards = new Cards($transport);
        $this->webhooks = new Webhooks($transport);
    }
}
