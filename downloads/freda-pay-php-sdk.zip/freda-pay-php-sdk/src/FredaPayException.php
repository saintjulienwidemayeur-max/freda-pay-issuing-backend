<?php

declare(strict_types=1);

namespace FredaPay\Issuing;

/**
 * Thrown for any non-2xx API response. Carries the same `code` and `message`
 * the API returned in its `{ "error": { "code", "message" } }` body.
 */
class FredaPayException extends \Exception
{
    /** @var int */
    public $status;

    /** @var string */
    public $code;

    public function __construct(int $status, string $code, string $message)
    {
        parent::__construct($message);
        $this->status = $status;
        $this->code = $code;
    }
}
