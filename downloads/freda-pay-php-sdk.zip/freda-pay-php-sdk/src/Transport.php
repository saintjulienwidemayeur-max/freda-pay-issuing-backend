<?php

declare(strict_types=1);

namespace FredaPay\Issuing;

/** Low-level HTTP transport used by every resource class. Not part of the public API. */
class Transport
{
    /** @var string */
    private $apiKey;

    /** @var string */
    private $baseUrl;

    public function __construct(string $apiKey, string $baseUrl)
    {
        $this->apiKey = $apiKey;
        $this->baseUrl = rtrim($baseUrl, '/');
    }

    /**
     * @param string $method
     * @param string $path
     * @param array<string, mixed>|null $body
     * @return array<string, mixed>
     * @throws FredaPayException
     */
    public function request(string $method, string $path, ?array $body = null): array
    {
        $url = $this->baseUrl . $path;

        $ch = curl_init($url);
        $headers = [
            'Authorization: Bearer ' . $this->apiKey,
            'Content-Type: application/json',
        ];

        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);

        if ($body !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
        }

        $raw = curl_exec($ch);
        if ($raw === false) {
            $error = curl_error($ch);
            curl_close($ch);
            throw new FredaPayException(0, 'NETWORK_ERROR', $error !== '' ? $error : 'Erreur réseau inconnue.');
        }

        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $data = $raw !== '' ? json_decode($raw, true) : [];
        if (!is_array($data)) {
            $data = [];
        }

        if ($status < 200 || $status >= 300) {
            $errorNode = $data['error'] ?? [];
            $code = is_array($errorNode) && isset($errorNode['code']) ? (string) $errorNode['code'] : 'UNKNOWN_ERROR';
            $message = is_array($errorNode) && isset($errorNode['message']) ? (string) $errorNode['message'] : ('HTTP ' . $status);
            throw new FredaPayException($status, $code, $message);
        }

        return $data;
    }

    /**
     * @param array<string, scalar|null> $params
     */
    public function buildQuery(array $params): string
    {
        $filtered = array_filter($params, static function ($v): bool {
            return $v !== null;
        });
        if (empty($filtered)) {
            return '';
        }
        return '?' . http_build_query($filtered);
    }
}
