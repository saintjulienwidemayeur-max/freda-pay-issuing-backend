<?php

declare(strict_types=1);

namespace FredaPay\Issuing;

class WebhookSignature
{
    /**
     * Verifies a webhook delivery's X-Freda-Signature header against the raw
     * request body. Use the RAW body (e.g. file_get_contents('php://input'),
     * before json_decode) - a re-encoded body will not produce the same
     * bytes and the signature will not match.
     *
     * @param string $rawBody
     * @param string $signatureHeader The full 'X-Freda-Signature' header value ("sha256=...").
     * @param string $secret Your webhook's whsec_... signing secret.
     */
    public static function verify(string $rawBody, string $signatureHeader, string $secret): bool
    {
        if (strpos($signatureHeader, 'sha256=') !== 0) {
            return false;
        }
        $received = substr($signatureHeader, strlen('sha256='));
        $expected = hash_hmac('sha256', $rawBody, $secret);

        if (strlen($received) !== strlen($expected)) {
            return false;
        }
        return hash_equals($expected, $received);
    }
}
