<?php

declare(strict_types=1);

namespace FredaPay\Issuing\Resources;

use FredaPay\Issuing\Transport;

class Webhooks
{
    /** @var Transport */
    private $transport;

    public function __construct(Transport $transport)
    {
        $this->transport = $transport;
    }

    /** @return array<string, mixed> secret is only ever returned here, once */
    public function register(string $url): array
    {
        return $this->transport->request('POST', '/webhooks', ['url' => $url]);
    }

    /** @return array<string, mixed> */
    public function get(): array
    {
        return $this->transport->request('GET', '/webhooks');
    }

    /** @return array<string, mixed> */
    public function delete(): array
    {
        return $this->transport->request('DELETE', '/webhooks');
    }

    /** @return array<string, mixed> */
    public function rotateSecret(): array
    {
        return $this->transport->request('POST', '/webhooks/rotate-secret');
    }
}
