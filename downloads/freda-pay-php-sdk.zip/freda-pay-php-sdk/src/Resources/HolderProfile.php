<?php

declare(strict_types=1);

namespace FredaPay\Issuing\Resources;

use FredaPay\Issuing\Transport;

class HolderProfile
{
    /** @var Transport */
    private $transport;

    public function __construct(Transport $transport)
    {
        $this->transport = $transport;
    }

    /** @return array<string, mixed> all holders: { holders: [...] } */
    public function all(): array
    {
        return $this->transport->request('GET', '/cards/holders');
    }

    /** @return array<string, mixed> { holder: {...} } */
    public function find(string $id): array
    {
        return $this->transport->request('GET', '/cards/holders/' . rawurlencode($id));
    }

    /**
     * Enroll a new holder (several are allowed; pass its id as holder_id when creating an individual card).
     *
     * @param array<string, mixed> $body
     * @return array<string, mixed>
     */
    public function create(array $body): array
    {
        return $this->transport->request('POST', '/cards/holders', $body);
    }

    /** @deprecated use all()/find()/create() @return array<string, mixed> */
    public function get(): array
    {
        return $this->transport->request('GET', '/cards/holder-profile');
    }

    /**
     * @param array<string, mixed> $body firstName, lastName, email, country, dob, identificationNumber, identity (type, number, imageUrl = Base64 data URI or direct https link, country), phoneShortCode, phoneNumber, address
     * @return array<string, mixed>
     */
    public function submit(array $body): array
    {
        return $this->transport->request('POST', '/cards/holder-profile', $body);
    }
}
