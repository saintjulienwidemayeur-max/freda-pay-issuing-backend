<?php

declare(strict_types=1);

namespace FredaPay\Issuing\Resources;

use FredaPay\Issuing\Transport;

class Payouts
{
    /** @var Transport */
    private $transport;

    public function __construct(Transport $transport)
    {
        $this->transport = $transport;
    }

    /**
     * @param array{amount: float, method: string, recipient: string, reference: string} $body
     * @return array<string, mixed>
     */
    public function create(array $body): array
    {
        return $this->transport->request('POST', '/payouts', $body);
    }

    /** @return array<string, mixed> */
    public function get(string $id): array
    {
        return $this->transport->request('GET', '/payouts/' . rawurlencode($id));
    }

    /**
     * Newest first, paginated; only the environment of the key (test or live).
     *
     * @param array{page?: int, page_size?: int} $params
     * @return array<string, mixed>
     */
    public function list(array $params = []): array
    {
        $query = $params ? '?' . http_build_query($params) : '';
        return $this->transport->request('GET', '/payouts' . $query);
    }
}
