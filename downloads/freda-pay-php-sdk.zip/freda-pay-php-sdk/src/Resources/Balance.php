<?php

declare(strict_types=1);

namespace FredaPay\Issuing\Resources;

use FredaPay\Issuing\Transport;

class Balance
{
    /** @var Transport */
    private $transport;

    public function __construct(Transport $transport)
    {
        $this->transport = $transport;
    }

    /** @return array<string, mixed> */
    public function get(): array
    {
        return $this->transport->request('GET', '/balance');
    }
}
