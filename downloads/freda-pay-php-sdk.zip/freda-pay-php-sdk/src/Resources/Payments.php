<?php

declare(strict_types=1);

namespace FredaPay\Issuing\Resources;

use FredaPay\Issuing\Transport;

class Payments
{
    /** @var Transport */
    private $transport;

    public function __construct(Transport $transport)
    {
        $this->transport = $transport;
    }

    /**
     * @param array{amount: float, method: string, reference: string, currency?: string, phone?: string, customer_name?: string, customer_email?: string, return_url?: string} $body (method 'carte' = card payment in USD: send the customer to checkout_url)
     * @return array<string, mixed>
     */
    public function create(array $body): array
    {
        return $this->transport->request('POST', '/payments', $body);
    }

    /** @return array<string, mixed> */
    public function get(string $id): array
    {
        return $this->transport->request('GET', '/payments/' . rawurlencode($id));
    }

    /**
     * Newest first, paginated; only the environment of the key (test or live).
     *
     * @param array{page?: int, page_size?: int} $params
     * @return array<string, mixed>
     */
    public function list(array $params = []): array
    {
        $query = $params ? '?' . http_build_query($params) : '';
        return $this->transport->request('GET', '/payments' . $query);
    }
}
