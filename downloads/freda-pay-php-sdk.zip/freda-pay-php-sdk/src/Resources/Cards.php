<?php

declare(strict_types=1);

namespace FredaPay\Issuing\Resources;

use FredaPay\Issuing\Transport;

class Cards
{
    /** @var Transport */
    private $transport;

    /** @var HolderProfile */
    public $holderProfile;

    public function __construct(Transport $transport)
    {
        $this->transport = $transport;
        $this->holderProfile = new HolderProfile($transport);
    }

    /**
     * @param array{reference: string, kind?: string, brand?: string, amount: float, business_name?: string} $body
     * @return array<string, mixed>
     */
    public function create(array $body): array
    {
        return $this->transport->request('POST', '/cards', $body);
    }

    /**
     * @param array{page?: int, page_size?: int} $params
     * @return array<string, mixed>
     */
    public function all(array $params = []): array
    {
        return $this->transport->request('GET', '/cards' . $this->transport->buildQuery($params));
    }

    /** @return array<string, mixed> */
    public function get(string $id): array
    {
        return $this->transport->request('GET', '/cards/' . rawurlencode($id));
    }

    /**
     * @param array{page?: int, page_size?: int} $params
     * @return array<string, mixed>
     */
    public function transactions(string $id, array $params = []): array
    {
        return $this->transport->request('GET', '/cards/' . rawurlencode($id) . '/transactions' . $this->transport->buildQuery($params));
    }

    /** @return array<string, mixed> */
    public function fund(string $id, float $amount, ?string $reference = null): array
    {
        return $this->transport->request('POST', '/cards/' . rawurlencode($id) . '/fund', array_filter(['amount' => $amount, 'reference' => $reference], fn ($v) => $v !== null));
    }

    /** @return array<string, mixed> */
    public function withdraw(string $id, float $amount, ?string $reference = null): array
    {
        return $this->transport->request('POST', '/cards/' . rawurlencode($id) . '/withdraw', array_filter(['amount' => $amount, 'reference' => $reference], fn ($v) => $v !== null));
    }

    /** @return array<string, mixed> */
    public function freeze(string $id): array
    {
        return $this->transport->request('POST', '/cards/' . rawurlencode($id) . '/freeze');
    }

    /** @return array<string, mixed> */
    public function unfreeze(string $id): array
    {
        return $this->transport->request('POST', '/cards/' . rawurlencode($id) . '/unfreeze');
    }

    /** @return array<string, mixed> */
    public function terminate(string $id): array
    {
        return $this->transport->request('POST', '/cards/' . rawurlencode($id) . '/terminate');
    }

    /**
     * Full card number, CVV, and expiry. Reserved for the account owner's own
     * purchases - never log or persist the result, never show it to anyone else.
     *
     * @return array<string, mixed>
     */
    public function reveal(string $id): array
    {
        return $this->transport->request('POST', '/cards/' . rawurlencode($id) . '/reveal');
    }

    /**
     * Sandbox only.
     * @return array<string, mixed>
     */
    public function simulateTransaction(string $id, float $amount, string $type): array
    {
        return $this->transport->request('POST', '/cards/' . rawurlencode($id) . '/simulate-transaction', [
            'amount' => $amount,
            'type' => $type,
        ]);
    }
}
