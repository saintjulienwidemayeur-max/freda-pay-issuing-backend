'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const crypto = require('node:crypto');
const { FredaPay, FredaPayError, verifyWebhookSignature } = require('../index');

/** A tiny mock of the Freda Pay API, just enough to prove the SDK's request/response handling. */
function startMockApi() {
  const server = http.createServer((req, res) => {
    let body = '';
    req.on('data', (c) => (body += c));
    req.on('end', () => {
      const parsed = body ? JSON.parse(body) : null;
      res.setHeader('Content-Type', 'application/json');

      if (req.headers.authorization !== 'Bearer sk_test_mock') {
        res.writeHead(401);
        return res.end(JSON.stringify({ error: { code: 'INVALID_API_KEY', message: 'Invalid key' } }));
      }

      if (req.method === 'POST' && req.url === '/payments') {
        res.writeHead(201);
        return res.end(JSON.stringify({ id: 'pay_1', reference: parsed.reference, amount: parsed.amount, status: 'pending' }));
      }
      if (req.method === 'GET' && req.url === '/payments?page=2&page_size=5') {
        res.writeHead(200);
        return res.end(JSON.stringify({ payments: [{ id: 'pay_9' }], pagination: { page: 2, page_size: 5, has_more: false }, mode: 'sandbox' }));
      }
      if (req.method === 'GET' && req.url === '/payouts') {
        res.writeHead(200);
        return res.end(JSON.stringify({ payouts: [], pagination: { page: 1, page_size: 20, has_more: false }, mode: 'sandbox' }));
      }
      if (req.method === 'GET' && req.url === '/payments/pay_1') {
        res.writeHead(200);
        return res.end(JSON.stringify({ id: 'pay_1', status: 'succeeded' }));
      }
      if (req.method === 'GET' && req.url.startsWith('/cards?')) {
        res.writeHead(200);
        return res.end(JSON.stringify({ cards: [{ id: 'card_1' }], pagination: { page: 1, page_size: 20, has_more: false } }));
      }
      if (req.method === 'POST' && req.url === '/cards/card_1/reveal') {
        res.writeHead(200);
        return res.end(JSON.stringify({ number: '4242424242424242', cvv: '123', expiry_month: 12, expiry_year: 2030 }));
      }
      if (req.method === 'POST' && req.url === '/payouts') {
        res.writeHead(400);
        return res.end(JSON.stringify({ error: { code: 'INVALID_RECIPIENT', message: 'Bad recipient' } }));
      }

      res.writeHead(404);
      res.end(JSON.stringify({ error: { code: 'NOT_FOUND', message: 'not found' } }));
    });
  });
  return server;
}

let baseUrl;
let server;

test.before(async () => {
  server = startMockApi();
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://localhost:${server.address().port}`;
});

test.after(async () => {
  await new Promise((r) => server.close(r));
});

test('throws clearly when no API key is given', () => {
  assert.throws(() => new FredaPay(), /apiKey is required/);
});

test('creates a payment and gets the expected shape back', async () => {
  const freda = new FredaPay('sk_test_mock', { baseUrl });
  const payment = await freda.payments.create({ amount: 1000, method: 'moncash', reference: 'CMD-1' });
  assert.equal(payment.id, 'pay_1');
  assert.equal(payment.reference, 'CMD-1');
});

test('fetches a payment by id', async () => {
  const freda = new FredaPay('sk_test_mock', { baseUrl });
  const payment = await freda.payments.get('pay_1');
  assert.equal(payment.status, 'succeeded');
});

test('lists cards with pagination query params', async () => {
  const freda = new FredaPay('sk_test_mock', { baseUrl });
  const result = await freda.cards.list({ page: 1, page_size: 20 });
  assert.equal(result.cards.length, 1);
  assert.equal(result.pagination.has_more, false);
});

test('reveals full card details', async () => {
  const freda = new FredaPay('sk_test_mock', { baseUrl });
  const details = await freda.cards.reveal('card_1');
  assert.equal(details.number, '4242424242424242');
  assert.equal(details.cvv, '123');
});

test('throws a FredaPayError with the API\'s code and message on failure', async () => {
  const freda = new FredaPay('sk_test_mock', { baseUrl });
  await assert.rejects(
    () => freda.payouts.create({ amount: 100, method: 'moncash', recipient: 'bad', reference: 'X' }),
    (err) => {
      assert.ok(err instanceof FredaPayError);
      assert.equal(err.code, 'INVALID_RECIPIENT');
      assert.equal(err.status, 400);
      return true;
    }
  );
});

test('throws INVALID_API_KEY when the key is wrong', async () => {
  const freda = new FredaPay('sk_test_wrong', { baseUrl });
  await assert.rejects(
    () => freda.payments.get('pay_1'),
    (err) => { assert.equal(err.code, 'INVALID_API_KEY'); return true; }
  );
});

test('verifyWebhookSignature accepts a correctly signed payload', () => {
  const secret = 'whsec_test123';
  const body = JSON.stringify({ event: 'payment.succeeded' });
  const sig = 'sha256=' + crypto.createHmac('sha256', secret).update(body).digest('hex');
  assert.equal(verifyWebhookSignature(body, sig, secret), true);
});

test('verifyWebhookSignature rejects a tampered payload', () => {
  const secret = 'whsec_test123';
  const body = JSON.stringify({ event: 'payment.succeeded' });
  const sig = 'sha256=' + crypto.createHmac('sha256', secret).update(body).digest('hex');
  assert.equal(verifyWebhookSignature(body + 'tampered', sig, secret), false);
});

test('verifyWebhookSignature rejects a wrong secret', () => {
  const secret = 'whsec_test123';
  const body = JSON.stringify({ event: 'payment.succeeded' });
  const sig = 'sha256=' + crypto.createHmac('sha256', secret).update(body).digest('hex');
  assert.equal(verifyWebhookSignature(body, sig, 'whsec_different'), false);
});

test('verifyWebhookSignature rejects a malformed header', () => {
  assert.equal(verifyWebhookSignature('body', 'not-a-real-signature', 'secret'), false);
  assert.equal(verifyWebhookSignature('body', '', 'secret'), false);
});

test('cards.holders list/create/get hit the multi-holder endpoints', async () => {
  const seen = [];
  const s = http.createServer((req, res) => {
    let b = ''; req.on('data', (c) => (b += c)); req.on('end', () => {
      seen.push(req.method + ' ' + req.url);
      res.setHeader('Content-Type', 'application/json'); res.writeHead(200); res.end('{}');
    });
  });
  await new Promise((r) => s.listen(0, r));
  const f = new FredaPay('sk_test_mock', { baseUrl: `http://localhost:${s.address().port}` });
  await f.cards.holders.list(); await f.cards.holders.create({ firstName: 'A' }); await f.cards.holders.get('mpc_1');
  await new Promise((r) => s.close(r));
  assert.deepEqual(seen, ['GET /cards/holders', 'POST /cards/holders', 'GET /cards/holders/mpc_1']);
});

test('payments.list and payouts.list call the paginated list endpoints', async () => {
  const freda = new FredaPay('sk_test_mock', { baseUrl });
  const page = await freda.payments.list({ page: 2, page_size: 5 });
  assert.equal(page.payments[0].id, 'pay_9');
  assert.equal(page.pagination.has_more, false);
  assert.equal(page.mode, 'sandbox');
  const payouts = await freda.payouts.list();
  assert.deepEqual(payouts.payouts, []);
});
