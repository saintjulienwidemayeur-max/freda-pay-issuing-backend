export interface FredaPayOptions {
  baseUrl?: string;
}

export interface Payment {
  id: string;
  reference: string;
  amount: number;
  currency: string;
  method: string;
  status: 'pending' | 'succeeded' | 'failed';
  fee: number | null;
  net_amount: number | null;
  checkout_url: string | null;
  provider_transaction_id: string | null;
  return_url?: string | null;
  failure_reason?: string | null;
  created_at: string;
  updated_at: string;
}

export interface Payout {
  id: string;
  reference: string;
  amount: number;
  method: 'moncash' | 'natcash' | 'bank';
  recipient: string;
  status: 'pending' | 'success' | 'failed';
  /** Freda Pay's fee, charged on top of `amount` (5 % for MonCash/Natcash, 100 HTG fixed for a bank transfer). */
  fee: number | null;
  /** amount + fee: what is held from the Gateway balance (given back if the withdrawal fails). */
  total_debited: number | null;
  /** Bank transfers only (requested from the dashboard): the transfer reference once sent. */
  bank_reference?: string | null;
  provider_reference: string | null;
  provider_transaction_id: string | null;
  failure_reason: string | null;
  created_at: string;
  updated_at: string;
}

export interface Balance {
  /** Environment these balances belong to: they are separate wallets, never mixed. */
  mode: 'sandbox' | 'live';
  /** MonCash / Natcash money (HTG). */
  gateway: { available: number; currency: 'HTG' };
  /** Card payments money (USD), fees already taken. */
  gateway_usd: { available: number; currency: 'USD' };
  gateway_balances: { HTG: number; USD: number };
  master_wallet: { available: number; currency: 'USD' };
}

export interface Card {
  id: string;
  reference: string;
  kind: 'individual' | 'business';
  brand: 'VISA' | 'MASTERCARD';
  status: 'pending' | 'active' | 'disabled' | 'terminated' | 'failed';
  masked_pan: string | null;
  balance: number;
  holder_name: string | null;
  failure_reason: string | null;
  created_at: string;
}

export interface Pagination {
  page: number;
  page_size: number;
  has_more: boolean;
}

export interface CardTransaction {
  id: string;
  type: string;
  mode: 'CREDIT' | 'DEBIT';
  amount: number;
  currency: string;
  merchant_name: string | null;
  merchant_city: string | null;
  date: string;
}

export interface CardDetails {
  number: string;
  cvv: string;
  expiry_month: number;
  expiry_year: number;
  holder_name: string | null;
}

export interface CardHolder {
  id: string;
  status: 'pending' | 'enrolled' | 'failed';
  first_name: string;
  last_name: string;
  email: string;
  country: string;
  photo_url: string | null;
  failure_reason: string | null;
  created_at: string;
}

export interface WebhookEndpoint {
  id: string;
  url: string;
  active: boolean;
  created_at: string;
}

export interface WebhookEndpointWithSecret extends WebhookEndpoint {
  secret: string;
}

export class FredaPayError extends Error {
  status: number;
  code: string;
}

export class FredaPay {
  constructor(apiKey: string, options?: FredaPayOptions);

  payments: {
    /** method 'carte' = card payment, always in USD (min 0.50): send the customer to `checkout_url`, a secure page that returns him to `return_url` afterwards. */
    create(body: { amount: number; method: 'moncash' | 'natcash' | 'moncash_ussd' | 'all' | 'carte'; reference: string; currency?: 'HTG' | 'USD'; phone?: string; customer_name?: string; customer_email?: string; return_url?: string }): Promise<Payment>;
    get(id: string): Promise<Payment>;
    /** Newest first, paginated. Only the environment of the key (test or live). */
    list(params?: { page?: number; page_size?: number }): Promise<{ payments: Payment[]; pagination: Pagination; mode: 'sandbox' | 'live' }>;
  };

  payouts: {
    create(body: { amount: number; method: 'moncash' | 'natcash'; recipient: string; reference: string }): Promise<Payout>;
    get(id: string): Promise<Payout>;
    list(params?: { page?: number; page_size?: number }): Promise<{ payouts: Payout[]; pagination: Pagination; mode: 'sandbox' | 'live' }>;
  };

  balance: {
    get(): Promise<Balance>;
  };

  cards: {
    create(body: { reference: string; kind?: 'individual' | 'business'; brand?: 'VISA' | 'MASTERCARD'; amount: number; business_name?: string; holder_id?: string }): Promise<Card>;
    list(params?: { page?: number; page_size?: number }): Promise<{ cards: Card[]; pagination: Pagination }>;
    get(id: string): Promise<Card>;
    transactions(id: string, params?: { page?: number; page_size?: number }): Promise<{ transactions: CardTransaction[]; month_spend: number; currency: string }>;
    /** `reference` makes the call safe to replay (same key = same operation, never debited twice). */
    fund(id: string, body: { amount: number; reference?: string }): Promise<Card & { fee: number; total_debited: number; idempotent_replay: boolean }>;
    withdraw(id: string, body: { amount: number; reference?: string }): Promise<Card & { fee: number; net_credited: number; idempotent_replay: boolean }>;
    freeze(id: string): Promise<Card>;
    unfreeze(id: string): Promise<Card>;
    terminate(id: string): Promise<Card>;
    reveal(id: string): Promise<CardDetails>;
    simulateTransaction(id: string, body: { amount: number; type: 'CREDIT' | 'DEBIT' }): Promise<{ simulated: boolean }>;
    holders: {
      list(): Promise<{ holders: CardHolder[] }>;
      get(id: string): Promise<{ holder: CardHolder }>;
      create(body: { firstName: string; lastName: string; email: string; country: string; dob: string; identificationNumber: string; identity: { type: 'NIN' | 'PASSPORT' | 'VOTERS_CARD' | 'DRIVERS_LICENSE'; number: string; imageUrl: string; country?: string }; phoneShortCode: string; phoneNumber: string; address: { street: string; city: string; state: string; postalCode: string; country: string }; photoUrl?: string }): Promise<{ holder: CardHolder }>;
    };
    holderProfile: {
      get(): Promise<{ profile: unknown }>;
      submit(body: Record<string, unknown>): Promise<{ profile: unknown }>;
    };
  };

  webhooks: {
    register(body: { url: string }): Promise<WebhookEndpointWithSecret>;
    get(): Promise<{ endpoint: WebhookEndpoint | null }>;
    delete(): Promise<{ deleted: boolean }>;
    rotateSecret(): Promise<WebhookEndpointWithSecret>;
  };
}

export function verifyWebhookSignature(rawBody: string | Buffer, signatureHeader: string, secret: string): boolean;
