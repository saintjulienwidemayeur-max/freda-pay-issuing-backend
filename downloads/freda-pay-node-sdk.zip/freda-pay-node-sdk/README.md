# @fredapay/issuing

SDK Node.js officiel pour l'API Freda Pay Issuing (paiements MonCash/Natcash/carte,
retraits, cartes virtuelles Visa/Mastercard, webhooks) en Haïti.

## Installation

```bash
npm install @fredapay/issuing
```

Nécessite Node.js 18 ou plus récent (utilise `fetch` natif). Aucune dépendance externe.

## Démarrage rapide

```js
const { FredaPay } = require('@fredapay/issuing');
const freda = new FredaPay(process.env.FREDA_SECRET_KEY); // sk_test_... ou sk_live_...

const payment = await freda.payments.create({
  amount: 1000,
  method: 'moncash',
  reference: 'CMD-1001',
});

console.log(payment.checkout_url); // redirigez votre client ici

// Plus tard, confirmez depuis votre serveur :
const confirmed = await freda.payments.get(payment.id);

// Historique, du plus récent au plus ancien (paginé, uniquement l'environnement de la clé) :
const { payments, pagination } = await freda.payments.list({ page: 1, page_size: 20 });
if (confirmed.status === 'succeeded') {
  // livrez la commande
}
```

### Paiement par carte (USD)

```js
const payment = await freda.payments.create({
  amount: 25, currency: 'USD', method: 'carte', reference: 'CMD-1002',
  customer_name: 'Marie Client',
  return_url: 'https://votre-site.com/commande/1002', // la page sécurisée y ramène le client
});
// Redirigez le client vers payment.checkout_url : il entre sa carte sur une page sécurisée Freda Pay.
// Confirmez toujours côté serveur (webhook payment.succeeded ou payments.get) avant de livrer.
```

Le paiement renvoyé contient aussi `customer_name`, `customer_email` (qui a payé). Frais carte : 7 % + 0,50 $ (Standard), 6 % + 0,50 $ (Pro), 5 % + 0,50 $ (Business).

> **Mode test (sandbox)** : avec une clé `sk_test_...`, payez par carte avec `4242 4242 4242 4242`, date `05/27`, CVV `088`. Aucun argent réel n'est débité.

Un paiement par carte crédite le solde `gateway_usd` (USD), frais déduits ; `balance.get()` renvoie aussi `gateway_balances: { HTG, USD }`. Un paiement refusé déclenche le webhook `payment.failed`.

## Cartes virtuelles

```js
const card = await freda.cards.create({
  reference: 'CARD-001',
  kind: 'business',
  brand: 'VISA',
  amount: 20,
  business_name: 'Boutique Lakay',
});

// La création est asynchrone : attendez que le statut devienne 'active'.
let current = card;
while (current.status === 'pending') {
  await new Promise((r) => setTimeout(r, 3000));
  current = await freda.cards.get(card.id);
}

await freda.cards.fund(card.id, { amount: 10, reference: 'FUND-001' }); // reference: safe to replay after a timeout

// Numéro complet, CVV, expiration - réservé au titulaire du compte.
const details = await freda.cards.reveal(card.id);
```

## Titulaires (cartes individuelles)

```js
const { holder } = await freda.cards.holders.create({
  firstName: 'Rose', lastName: 'Lakay', email: 'rose@example.com', country: 'HT',
  dob: '1990-05-12', identificationNumber: 'ID123456',
  identity: { type: 'PASSPORT', number: 'P1234567', imageUrl: 'data:image/jpeg;base64,/9j/4AAQ...' /* or a direct https link to the image */ },
  phoneShortCode: '+509', phoneNumber: '37001234',
  address: { street: '12 Rue Example', city: 'Port-au-Prince', state: 'Ouest', postalCode: 'HT6110', country: 'HT' },
});
await freda.cards.create({ reference: 'CARD-002', kind: 'individual', amount: 20, holder_id: holder.id });
```

## Webhooks

```js
const express = require('express');
const { verifyWebhookSignature } = require('@fredapay/issuing');

const app = express();
app.post('/webhooks/freda', express.raw({ type: 'application/json' }), (req, res) => {
  const signature = req.headers['x-freda-signature'];
  const valid = verifyWebhookSignature(req.body, signature, process.env.FREDA_WEBHOOK_SECRET);
  if (!valid) return res.sendStatus(401);

  const event = JSON.parse(req.body);
  switch (event.event) {
    case 'payment.succeeded':
      // livrez la commande event.data.reference
      break;
    case 'card.created':
      // notifiez l'utilisateur que sa carte est prête
      break;
  }
  res.sendStatus(200);
});
```

Utilisez `express.raw()` (pas `express.json()`) sur cette route : la vérification de
signature a besoin du corps brut, un corps re-sérialisé ne redonne pas les mêmes octets.

## Gestion des erreurs

Chaque appel qui échoue lève une `FredaPayError` avec le même `code` et `message`
que l'API :

```js
const { FredaPay, FredaPayError } = require('@fredapay/issuing');

try {
  await freda.payouts.create({ amount: 500, method: 'moncash', recipient: '509...', reference: 'P-1' });
} catch (err) {
  if (err instanceof FredaPayError) {
    console.error(err.code, err.message); // ex: INSUFFICIENT_BALANCE
  }
}
```

## Référence complète

Voir [api.fredapay.com/docs](https://issuing.fredapay.com/docs) et la
[spec OpenAPI](https://api.fredapay.com/openapi.yaml).

## Licence

MIT

### Withdrawal fees
`payouts.create` (MonCash / Natcash) costs 5 % of the amount, charged on top: `balance >= amount + fee` is required, `payout.fee` and `payout.total_debited` tell you exactly what was taken, and it is given back in full if the withdrawal fails. Bank transfers are requested from the dashboard (fixed fee, processed by hand) and are not available through the API.
