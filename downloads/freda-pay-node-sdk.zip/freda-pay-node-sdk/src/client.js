'use strict';

const DEFAULT_BASE_URL = 'https://api.fredapay.com/v1';

/** Thrown for any non-2xx API response. Carries the same code/message the API returned. */
class FredaPayError extends Error {
  constructor(status, code, message) {
    super(message);
    this.name = 'FredaPayError';
    this.status = status;
    this.code = code;
  }
}

class FredaPay {
  /**
   * @param {string} apiKey - Your sk_test_... or sk_live_... secret key.
   * @param {{baseUrl?: string}} [options]
   */
  constructor(apiKey, options) {
    if (!apiKey) throw new Error('FredaPay: apiKey is required (sk_test_... or sk_live_...).');
    this.apiKey = apiKey;
    this.baseUrl = (options && options.baseUrl) || DEFAULT_BASE_URL;

    this.payments = {
      create: (body) => this._request('POST', '/payments', body),
      get: (id) => this._request('GET', `/payments/${encodeURIComponent(id)}`),
      list: (params) => this._request('GET', `/payments${qs(params)}`),
    };

    this.payouts = {
      create: (body) => this._request('POST', '/payouts', body),
      get: (id) => this._request('GET', `/payouts/${encodeURIComponent(id)}`),
      list: (params) => this._request('GET', `/payouts${qs(params)}`),
    };

    this.balance = {
      get: () => this._request('GET', '/balance'),
    };

    this.cards = {
      create: (body) => this._request('POST', '/cards', body),
      list: (params) => this._request('GET', `/cards${qs(params)}`),
      get: (id) => this._request('GET', `/cards/${encodeURIComponent(id)}`),
      transactions: (id, params) => this._request('GET', `/cards/${encodeURIComponent(id)}/transactions${qs(params)}`),
      fund: (id, body) => this._request('POST', `/cards/${encodeURIComponent(id)}/fund`, body),
      withdraw: (id, body) => this._request('POST', `/cards/${encodeURIComponent(id)}/withdraw`, body),
      freeze: (id) => this._request('POST', `/cards/${encodeURIComponent(id)}/freeze`),
      unfreeze: (id) => this._request('POST', `/cards/${encodeURIComponent(id)}/unfreeze`),
      terminate: (id) => this._request('POST', `/cards/${encodeURIComponent(id)}/terminate`),
      /** Full number, CVV, expiry. Sensitive - see class-level security note. */
      reveal: (id) => this._request('POST', `/cards/${encodeURIComponent(id)}/reveal`),
      simulateTransaction: (id, body) => this._request('POST', `/cards/${encodeURIComponent(id)}/simulate-transaction`, body),
      /** Card holders: create several, pick one (holder_id) when issuing an individual card. */
      holders: {
        list: () => this._request('GET', '/cards/holders'),
        get: (id) => this._request('GET', `/cards/holders/${encodeURIComponent(id)}`),
        create: (body) => this._request('POST', '/cards/holders', body),
      },
      /** @deprecated use holders.create - kept for older integrations. */
      holderProfile: {
        get: () => this._request('GET', '/cards/holder-profile'),
        submit: (body) => this._request('POST', '/cards/holder-profile', body),
      },
    };

    this.webhooks = {
      register: (body) => this._request('POST', '/webhooks', body),
      get: () => this._request('GET', '/webhooks'),
      delete: () => this._request('DELETE', '/webhooks'),
      rotateSecret: () => this._request('POST', '/webhooks/rotate-secret'),
    };
  }

  async _request(method, path, body) {
    const res = await fetch(this.baseUrl + path, {
      method,
      headers: {
        Authorization: `Bearer ${this.apiKey}`,
        'Content-Type': 'application/json',
      },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });

    let data = null;
    try { data = await res.json(); } catch (e) { /* empty body */ }

    if (!res.ok) {
      const err = (data && data.error) || {};
      throw new FredaPayError(res.status, err.code || 'UNKNOWN_ERROR', err.message || `HTTP ${res.status}`);
    }
    return data;
  }
}

/**
 * Verifies a webhook delivery's X-Freda-Signature header against the raw
 * request body. Use the RAW body (before JSON.parse) - a re-serialized
 * body will not produce the same bytes and the signature will not match.
 *
 * @param {string|Buffer} rawBody
 * @param {string} signatureHeader - the full 'X-Freda-Signature' header value ("sha256=...")
 * @param {string} secret - your webhook's whsec_... signing secret
 * @returns {boolean}
 */
function verifyWebhookSignature(rawBody, signatureHeader, secret) {
  const crypto = require('crypto');
  if (!signatureHeader || !signatureHeader.startsWith('sha256=')) return false;
  const expected = crypto.createHmac('sha256', secret).update(rawBody).digest('hex');
  const received = signatureHeader.slice('sha256='.length);
  const expectedBuf = Buffer.from(expected, 'hex');
  const receivedBuf = Buffer.from(received, 'hex');
  if (expectedBuf.length !== receivedBuf.length) return false;
  return crypto.timingSafeEqual(expectedBuf, receivedBuf);
}

function qs(params) {
  if (!params) return '';
  const entries = Object.entries(params).filter(([, v]) => v !== undefined && v !== null);
  if (!entries.length) return '';
  return '?' + entries.map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join('&');
}

module.exports = { FredaPay, FredaPayError, verifyWebhookSignature };
